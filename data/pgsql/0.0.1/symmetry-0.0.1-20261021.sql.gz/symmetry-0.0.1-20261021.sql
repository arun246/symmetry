--
-- PostgreSQL database dump
--

\restrict ai4ie9PjbA3BARSCo1kc2cIWJxpJWz580BI5aERVgMoxFmQjKqcEaCGgMk6Fe26

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.setting DROP CONSTRAINT IF EXISTS fk_setting_updated_by;
ALTER TABLE IF EXISTS ONLY public.contract DROP CONSTRAINT IF EXISTS fk_contract_org;
ALTER TABLE IF EXISTS ONLY public.contract DROP CONSTRAINT IF EXISTS fk_contract_created_by;
ALTER TABLE IF EXISTS ONLY public.config_request DROP CONSTRAINT IF EXISTS fk_config_request_reviewed_by;
ALTER TABLE IF EXISTS ONLY public.config_request DROP CONSTRAINT IF EXISTS fk_config_request_requested_by;
ALTER TABLE IF EXISTS ONLY public.config_request DROP CONSTRAINT IF EXISTS fk_config_request_org;
ALTER TABLE IF EXISTS ONLY public.config_request DROP CONSTRAINT IF EXISTS fk_config_request_contract;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS fk_audit_actor;
ALTER TABLE IF EXISTS ONLY public.app_user DROP CONSTRAINT IF EXISTS fk_app_user_org;
ALTER TABLE IF EXISTS ONLY public.acceptance DROP CONSTRAINT IF EXISTS fk_acceptance_contract;
DROP TRIGGER IF EXISTS trg_organization_set_updated_at ON public.organization;
DROP TRIGGER IF EXISTS trg_contract_set_updated_at ON public.contract;
DROP INDEX IF EXISTS public.uq_setting_scope_key;
DROP INDEX IF EXISTS public.uq_setting_global_key;
DROP INDEX IF EXISTS public.idx_setting_scope;
DROP INDEX IF EXISTS public.idx_contract_payload;
DROP INDEX IF EXISTS public.idx_contract_org_created;
DROP INDEX IF EXISTS public.idx_config_request_status;
DROP INDEX IF EXISTS public.idx_config_request_org;
DROP INDEX IF EXISTS public.idx_audit_created_at;
DROP INDEX IF EXISTS public.idx_audit_actor;
DROP INDEX IF EXISTS public.idx_audit_action;
DROP INDEX IF EXISTS public.idx_app_user_org;
DROP INDEX IF EXISTS public.idx_acceptance_worker_id;
DROP INDEX IF EXISTS public.flyway_schema_history_s_idx;
ALTER TABLE IF EXISTS ONLY public.organization DROP CONSTRAINT IF EXISTS uq_organization_slug;
ALTER TABLE IF EXISTS ONLY public.contract DROP CONSTRAINT IF EXISTS uq_contract_module_version;
ALTER TABLE IF EXISTS ONLY public.app_user DROP CONSTRAINT IF EXISTS uq_app_user_subject;
ALTER TABLE IF EXISTS ONLY public.app_user DROP CONSTRAINT IF EXISTS uq_app_user_email;
ALTER TABLE IF EXISTS ONLY public.acceptance DROP CONSTRAINT IF EXISTS uq_acceptance_contract_worker;
ALTER TABLE IF EXISTS ONLY public.setting DROP CONSTRAINT IF EXISTS setting_pkey;
ALTER TABLE IF EXISTS ONLY public.organization DROP CONSTRAINT IF EXISTS organization_pkey;
ALTER TABLE IF EXISTS ONLY public.flyway_schema_history DROP CONSTRAINT IF EXISTS flyway_schema_history_pk;
ALTER TABLE IF EXISTS ONLY public.contract DROP CONSTRAINT IF EXISTS contract_pkey;
ALTER TABLE IF EXISTS ONLY public.config_request DROP CONSTRAINT IF EXISTS config_request_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.app_user DROP CONSTRAINT IF EXISTS app_user_pkey;
ALTER TABLE IF EXISTS ONLY public.acceptance DROP CONSTRAINT IF EXISTS acceptance_pkey;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.setting;
DROP TABLE IF EXISTS public.organization;
DROP TABLE IF EXISTS public.flyway_schema_history;
DROP TABLE IF EXISTS public.contract;
DROP TABLE IF EXISTS public.config_request;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP TABLE IF EXISTS public.app_user;
DROP TABLE IF EXISTS public.acceptance;
DROP FUNCTION IF EXISTS public.set_row_updated_at();
DROP FUNCTION IF EXISTS public.set_contract_updated_at();
--
-- Name: set_contract_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_contract_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;


--
-- Name: set_row_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_row_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;


--
-- Name: FUNCTION set_row_updated_at(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.set_row_updated_at() IS 'Sets updated_at = now() on UPDATE for tables that use it.';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acceptance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acceptance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    contract_id uuid NOT NULL,
    worker_id text NOT NULL,
    task_document_hash text NOT NULL,
    signature text NOT NULL,
    worker_public_key text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    agreements jsonb DEFAULT '[]'::jsonb NOT NULL,
    accepted_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_acceptance_agreements_is_array CHECK ((jsonb_typeof(agreements) = 'array'::text)),
    CONSTRAINT chk_acceptance_worker_id_not_blank CHECK ((length(btrim(worker_id)) > 0))
);


--
-- Name: TABLE acceptance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.acceptance IS 'A signed record that a worker accepted a task document before working; anyone who submits without one is ineligible.';


--
-- Name: COLUMN acceptance.agreements; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.acceptance.agreements IS 'The agreements (honesty, scope, ai-declaration, ...) the worker accepted, stored as a JSON array.';


--
-- Name: app_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_user (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    subject text NOT NULL,
    email text NOT NULL,
    display_name text NOT NULL,
    role text NOT NULL,
    org_id uuid,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_app_user_display_name_not_blank CHECK ((length(btrim(display_name)) > 0)),
    CONSTRAINT chk_app_user_email_not_blank CHECK ((length(btrim(email)) > 0)),
    CONSTRAINT chk_app_user_role CHECK ((role = ANY (ARRAY['WORKER'::text, 'PUBLISHER'::text, 'ADMIN'::text]))),
    CONSTRAINT chk_app_user_status CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'SUSPENDED'::text])))
);


--
-- Name: TABLE app_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.app_user IS 'Local mirror of a Keycloak identity; Keycloak holds credentials, this holds role and org.';


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    actor_id uuid,
    actor_email text,
    actor_role text,
    action text NOT NULL,
    target_type text NOT NULL,
    target_id text,
    before jsonb,
    after jsonb,
    ip text,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_audit_action_not_blank CHECK ((length(btrim(action)) > 0)),
    CONSTRAINT chk_audit_target_type_not_blank CHECK ((length(btrim(target_type)) > 0))
);


--
-- Name: TABLE audit_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.audit_log IS 'Append-only record of privileged changes (actor, action, before, after).';


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: config_request; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_request (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    contract_id uuid,
    requested_by uuid NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    reason text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    review_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_config_request_key_not_blank CHECK ((length(btrim(key)) > 0)),
    CONSTRAINT chk_config_request_reason_not_blank CHECK ((length(btrim(reason)) > 0)),
    CONSTRAINT chk_config_request_reviewed CHECK (((status = 'PENDING'::text) OR ((reviewed_by IS NOT NULL) AND (reviewed_at IS NOT NULL)))),
    CONSTRAINT chk_config_request_status CHECK ((status = ANY (ARRAY['PENDING'::text, 'APPROVED'::text, 'REJECTED'::text, 'APPLIED'::text])))
);


--
-- Name: TABLE config_request; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.config_request IS 'An organization request for a task-specific configuration tweak, reviewed by an admin.';


--
-- Name: contract; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_id text NOT NULL,
    version text NOT NULL,
    task_kind text NOT NULL,
    language text NOT NULL,
    disclosure_tier text NOT NULL,
    work_kind text DEFAULT 'COMPUTE'::text NOT NULL,
    lifecycle_state text DEFAULT 'DRAFT'::text NOT NULL,
    task_document text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    org_id uuid,
    created_by uuid,
    CONSTRAINT chk_contract_disclosure_tier CHECK ((disclosure_tier = ANY (ARRAY['L0'::text, 'L1'::text, 'L2'::text]))),
    CONSTRAINT chk_contract_language_not_blank CHECK ((length(btrim(language)) > 0)),
    CONSTRAINT chk_contract_lifecycle_state CHECK ((lifecycle_state = ANY (ARRAY['DRAFT'::text, 'NEGOTIATED'::text, 'ACCEPTED'::text, 'SUBMITTED'::text, 'JUDGED'::text, 'MERGED'::text]))),
    CONSTRAINT chk_contract_module_id_not_blank CHECK ((length(btrim(module_id)) > 0)),
    CONSTRAINT chk_contract_payload_is_object CHECK ((jsonb_typeof(payload) = 'object'::text)),
    CONSTRAINT chk_contract_task_document_not_blank CHECK ((length(btrim(task_document)) > 0)),
    CONSTRAINT chk_contract_task_kind CHECK ((task_kind = ANY (ARRAY['optimize'::text, 'build'::text]))),
    CONSTRAINT chk_contract_version_not_blank CHECK ((length(btrim(version)) > 0)),
    CONSTRAINT chk_contract_work_kind CHECK ((work_kind = ANY (ARRAY['COMPUTE'::text, 'SERVICE'::text, 'UI'::text, 'DATA'::text, 'SYSTEM'::text])))
);


--
-- Name: TABLE contract; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.contract IS 'Machine-readable job card: the signed task document plus budgets, oracle, and scoring payload.';


--
-- Name: COLUMN contract.lifecycle_state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contract.lifecycle_state IS 'Where the contract is in its life: DRAFT -> NEGOTIATED -> ACCEPTED -> SUBMITTED -> JUDGED -> MERGED.';


--
-- Name: COLUMN contract.payload; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contract.payload IS 'Free-form JSON card (signature, invariants, budgets, oracle, scoring); shape-checked to be an object.';


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: organization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organization (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_organization_name_not_blank CHECK ((length(btrim(name)) > 0)),
    CONSTRAINT chk_organization_slug_not_blank CHECK ((length(btrim(slug)) > 0)),
    CONSTRAINT chk_organization_status CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'SUSPENDED'::text])))
);


--
-- Name: TABLE organization; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.organization IS 'A publisher company (or task committee) that owns contracts.';


--
-- Name: setting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setting (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scope text NOT NULL,
    scope_id uuid,
    key text NOT NULL,
    value jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_setting_key_not_blank CHECK ((length(btrim(key)) > 0)),
    CONSTRAINT chk_setting_scope CHECK ((scope = ANY (ARRAY['GLOBAL'::text, 'ORG'::text, 'CONTRACT'::text, 'USER'::text]))),
    CONSTRAINT chk_setting_scope_id CHECK ((((scope = 'GLOBAL'::text) AND (scope_id IS NULL)) OR ((scope <> 'GLOBAL'::text) AND (scope_id IS NOT NULL)))),
    CONSTRAINT chk_setting_version_positive CHECK ((version > 0))
);


--
-- Name: TABLE setting; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.setting IS 'Scoped configuration resolved as USER > CONTRACT > ORG > GLOBAL.';


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Data for Name: acceptance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.acceptance (id, contract_id, worker_id, task_document_hash, signature, worker_public_key, verified, agreements, accepted_at) FROM stdin;
\.


--
-- Data for Name: app_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_user (id, subject, email, display_name, role, org_id, status, created_at, updated_at) FROM stdin;
4f2749bc-7f40-462a-a3a6-7c3b39e13b1d	dev-worker	worker@symmetry.local	Wren Worker	WORKER	f872c8a9-2b1e-40ff-b0e4-97d1f670a295	ACTIVE	2026-10-21 10:24:29.037055+00	2026-10-21 10:24:29.037061+00
1f85d84c-cf62-4787-b16e-857aab13bc38	dev-publisher	publisher@symmetry.local	Pat Publisher	PUBLISHER	f872c8a9-2b1e-40ff-b0e4-97d1f670a295	ACTIVE	2026-10-21 10:24:29.244778+00	2026-10-21 10:24:29.244781+00
f90133e2-dd6b-4352-a28e-aeb6bfd4e098	dev-admin	admin@symmetry.local	Avery Admin	ADMIN	\N	ACTIVE	2026-10-21 10:24:29.286844+00	2026-10-21 10:24:29.286847+00
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, actor_id, actor_email, actor_role, action, target_type, target_id, before, after, ip, user_agent, created_at) FROM stdin;
1	4f2749bc-7f40-462a-a3a6-7c3b39e13b1d	worker@symmetry.local	WORKER	config.update	setting	7e09815a-b0a5-433b-9c9f-2b9fa277b20f	\N	{"key": "notifications.email", "scope": "USER", "value": false}	0:0:0:0:0:0:0:1	curl/8.14.1	2026-10-21 10:24:50.633995+00
2	4f2749bc-7f40-462a-a3a6-7c3b39e13b1d	worker@symmetry.local	WORKER	config.update	setting	a61764ad-554a-4841-95a5-50c42724849a	\N	{"key": "worker.maxConcurrent", "scope": "USER", "value": 3}	0:0:0:0:0:0:0:1	curl/8.14.1	2026-10-21 10:24:50.738761+00
3	f90133e2-dd6b-4352-a28e-aeb6bfd4e098	admin@symmetry.local	ADMIN	config.update	setting	e03c8db0-294a-412b-943a-8dddd9e77946	\N	{"key": "worker.maxConcurrent", "scope": "GLOBAL", "value": 6}	0:0:0:0:0:0:0:1	curl/8.14.1	2026-10-21 10:24:51.244736+00
4	1f85d84c-cf62-4787-b16e-857aab13bc38	publisher@symmetry.local	PUBLISHER	config.request	config_request	df5cba2e-fda3-404d-955f-3083e1a850b5	\N	{"key": "evaluation.timeLimitSeconds", "orgId": "f872c8a9-2b1e-40ff-b0e4-97d1f670a295", "scope": "ORG"}	0:0:0:0:0:0:0:1	curl/8.14.1	2026-10-21 10:24:51.496758+00
5	1f85d84c-cf62-4787-b16e-857aab13bc38	publisher@symmetry.local	PUBLISHER	contract.publish	contract	2b752c0e-497b-43b1-92b8-01318727b714	\N	{"version": "1.0.0", "moduleId": "module.demo.resize", "taskKind": "optimize"}	0:0:0:0:0:0:0:1	curl/8.14.1	2026-10-21 10:25:19.807427+00
6	f90133e2-dd6b-4352-a28e-aeb6bfd4e098	admin@symmetry.local	ADMIN	config.update	setting	c04794c3-f96a-4fb5-a409-fa8bc2693904	\N	{"key": "evaluation.timeLimitSeconds", "scope": "ORG", "value": 9}	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64; rv:157.0) Gecko/20100101 Firefox/157.0	2026-10-21 11:10:01.854437+00
7	f90133e2-dd6b-4352-a28e-aeb6bfd4e098	admin@symmetry.local	ADMIN	config.approve	config_request	df5cba2e-fda3-404d-955f-3083e1a850b5	\N	{"key": "evaluation.timeLimitSeconds", "scope": "ORG", "scopeId": "f872c8a9-2b1e-40ff-b0e4-97d1f670a295"}	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64; rv:157.0) Gecko/20100101 Firefox/157.0	2026-10-21 11:10:02.301789+00
\.


--
-- Data for Name: config_request; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config_request (id, org_id, contract_id, requested_by, key, value, reason, status, reviewed_by, reviewed_at, review_note, created_at) FROM stdin;
df5cba2e-fda3-404d-955f-3083e1a850b5	f872c8a9-2b1e-40ff-b0e4-97d1f670a295	\N	1f85d84c-cf62-4787-b16e-857aab13bc38	evaluation.timeLimitSeconds	9	tight kernel	APPLIED	f90133e2-dd6b-4352-a28e-aeb6bfd4e098	2026-10-21 11:10:02.294897+00	good	2026-10-21 10:24:51.480255+00
\.


--
-- Data for Name: contract; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract (id, module_id, version, task_kind, language, disclosure_tier, work_kind, lifecycle_state, task_document, payload, created_at, updated_at, org_id, created_by) FROM stdin;
2b752c0e-497b-43b1-92b8-01318727b714	module.demo.resize	1.0.0	optimize	java	L1	COMPUTE	DRAFT	Implement resize exactly as specified.	{"oracle": {"holdout": "hidden", "properties": "ref"}, "scoring": {"gate": "all_pass"}, "signature": {"name": "resize"}, "invariants": ["dims_match", "alpha_preserved"], "resourceBudget": {"timeMs": 12, "peakMemMb": 8, "artifactKb": 64}}	2026-10-21 10:25:19.757496+00	2026-10-21 10:25:19.771249+00	f872c8a9-2b1e-40ff-b0e4-97d1f670a295	1f85d84c-cf62-4787-b16e-857aab13bc38
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	baseline	SQL	V1__baseline.sql	-459249133	symmetry	2026-10-19 08:11:58.606612	311	t
2	2	identity config audit	SQL	V2__identity_config_audit.sql	-621508985	symmetry	2026-10-21 10:24:05.268159	923	t
\.


--
-- Data for Name: organization; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organization (id, slug, name, status, created_at, updated_at) FROM stdin;
f872c8a9-2b1e-40ff-b0e4-97d1f670a295	acme	Acme Engineering	ACTIVE	2026-10-21 10:24:28.7996+00	2026-10-21 10:24:28.799604+00
\.


--
-- Data for Name: setting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.setting (id, scope, scope_id, key, value, version, updated_by, updated_at) FROM stdin;
7e09815a-b0a5-433b-9c9f-2b9fa277b20f	USER	4f2749bc-7f40-462a-a3a6-7c3b39e13b1d	notifications.email	false	1	4f2749bc-7f40-462a-a3a6-7c3b39e13b1d	2026-10-21 10:24:50.595306+00
a61764ad-554a-4841-95a5-50c42724849a	USER	4f2749bc-7f40-462a-a3a6-7c3b39e13b1d	worker.maxConcurrent	3	1	4f2749bc-7f40-462a-a3a6-7c3b39e13b1d	2026-10-21 10:24:50.73061+00
e03c8db0-294a-412b-943a-8dddd9e77946	GLOBAL	\N	worker.maxConcurrent	6	1	f90133e2-dd6b-4352-a28e-aeb6bfd4e098	2026-10-21 10:24:51.236854+00
c04794c3-f96a-4fb5-a409-fa8bc2693904	ORG	f872c8a9-2b1e-40ff-b0e4-97d1f670a295	evaluation.timeLimitSeconds	9	1	f90133e2-dd6b-4352-a28e-aeb6bfd4e098	2026-10-21 11:10:01.513302+00
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 7, true);


--
-- Name: acceptance acceptance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acceptance
    ADD CONSTRAINT acceptance_pkey PRIMARY KEY (id);


--
-- Name: app_user app_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT app_user_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: config_request config_request_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_request
    ADD CONSTRAINT config_request_pkey PRIMARY KEY (id);


--
-- Name: contract contract_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT contract_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: organization organization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- Name: setting setting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setting
    ADD CONSTRAINT setting_pkey PRIMARY KEY (id);


--
-- Name: acceptance uq_acceptance_contract_worker; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acceptance
    ADD CONSTRAINT uq_acceptance_contract_worker UNIQUE (contract_id, worker_id);


--
-- Name: app_user uq_app_user_email; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT uq_app_user_email UNIQUE (email);


--
-- Name: app_user uq_app_user_subject; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT uq_app_user_subject UNIQUE (subject);


--
-- Name: contract uq_contract_module_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT uq_contract_module_version UNIQUE (module_id, version);


--
-- Name: organization uq_organization_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT uq_organization_slug UNIQUE (slug);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_acceptance_worker_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_acceptance_worker_id ON public.acceptance USING btree (worker_id);


--
-- Name: idx_app_user_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_app_user_org ON public.app_user USING btree (org_id);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_action ON public.audit_log USING btree (action, created_at DESC);


--
-- Name: idx_audit_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_actor ON public.audit_log USING btree (actor_id, created_at DESC);


--
-- Name: idx_audit_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_created_at ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_config_request_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_request_org ON public.config_request USING btree (org_id, created_at DESC);


--
-- Name: idx_config_request_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_request_status ON public.config_request USING btree (status, created_at);


--
-- Name: idx_contract_org_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_org_created ON public.contract USING btree (org_id, created_at DESC);


--
-- Name: idx_contract_payload; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_payload ON public.contract USING gin (payload jsonb_path_ops);


--
-- Name: idx_setting_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_setting_scope ON public.setting USING btree (scope, scope_id);


--
-- Name: uq_setting_global_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_setting_global_key ON public.setting USING btree (key) WHERE (scope = 'GLOBAL'::text);


--
-- Name: uq_setting_scope_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_setting_scope_key ON public.setting USING btree (scope, scope_id, key) WHERE (scope <> 'GLOBAL'::text);


--
-- Name: contract trg_contract_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_contract_set_updated_at BEFORE UPDATE ON public.contract FOR EACH ROW EXECUTE FUNCTION public.set_contract_updated_at();


--
-- Name: organization trg_organization_set_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_organization_set_updated_at BEFORE UPDATE ON public.organization FOR EACH ROW EXECUTE FUNCTION public.set_row_updated_at();


--
-- Name: acceptance fk_acceptance_contract; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acceptance
    ADD CONSTRAINT fk_acceptance_contract FOREIGN KEY (contract_id) REFERENCES public.contract(id) ON DELETE CASCADE;


--
-- Name: app_user fk_app_user_org; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_user
    ADD CONSTRAINT fk_app_user_org FOREIGN KEY (org_id) REFERENCES public.organization(id) ON DELETE SET NULL;


--
-- Name: audit_log fk_audit_actor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT fk_audit_actor FOREIGN KEY (actor_id) REFERENCES public.app_user(id) ON DELETE SET NULL;


--
-- Name: config_request fk_config_request_contract; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_request
    ADD CONSTRAINT fk_config_request_contract FOREIGN KEY (contract_id) REFERENCES public.contract(id) ON DELETE SET NULL;


--
-- Name: config_request fk_config_request_org; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_request
    ADD CONSTRAINT fk_config_request_org FOREIGN KEY (org_id) REFERENCES public.organization(id) ON DELETE CASCADE;


--
-- Name: config_request fk_config_request_requested_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_request
    ADD CONSTRAINT fk_config_request_requested_by FOREIGN KEY (requested_by) REFERENCES public.app_user(id) ON DELETE CASCADE;


--
-- Name: config_request fk_config_request_reviewed_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_request
    ADD CONSTRAINT fk_config_request_reviewed_by FOREIGN KEY (reviewed_by) REFERENCES public.app_user(id) ON DELETE SET NULL;


--
-- Name: contract fk_contract_created_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT fk_contract_created_by FOREIGN KEY (created_by) REFERENCES public.app_user(id) ON DELETE SET NULL;


--
-- Name: contract fk_contract_org; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT fk_contract_org FOREIGN KEY (org_id) REFERENCES public.organization(id) ON DELETE SET NULL;


--
-- Name: setting fk_setting_updated_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setting
    ADD CONSTRAINT fk_setting_updated_by FOREIGN KEY (updated_by) REFERENCES public.app_user(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict ai4ie9PjbA3BARSCo1kc2cIWJxpJWz580BI5aERVgMoxFmQjKqcEaCGgMk6Fe26

